import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

/**
  *
  * Beschreibung
  *
  * @version 1.0 vom 20.10.2017
  * @author 
  */

public class Minesweeper extends JFrame {
  // Anfang Attribute
  // Ende Attribute
  
  public Minesweeper() { 
  } // end of public Minesweeper
  
  // Anfang Methoden
  
  public static void main(String[] args) {
    new Menue();
  } // end of main
  
  // Ende Methoden
} // end of class Minesweeper

